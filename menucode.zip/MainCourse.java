class MainCourse extends Food
{
    private char veg;
    private char gluten;
    
    public MainCourse(String name, String desc, double price, String course, char veg, char gluten)
    {
        super(name, desc, price, course);
        this.veg = veg;
        this.gluten = gluten;
        setVeg(veg);
        setGluten(gluten);
    }  
}