class Dessert extends Food 
{
    private int calories;
    private char nuts;
    
    public Dessert(String name, String desc, double price, String course, int calories, char nuts)
    {
        super(name, desc, price, course);
        this.calories = calories;
        this.nuts = nuts;
        setCalories(calories);
        setNuts(nuts);
    }
}