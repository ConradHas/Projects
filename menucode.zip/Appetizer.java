
class Appetizer extends Food
{
    private int portion;
    private String temp;
    
    public Appetizer(String name, String desc, double price, String course, int portion, String temp)
    {
        super(name, desc, price, course);
        this.portion = portion;
        this.temp = temp;
        setTemp(temp);
        setPortion(portion);
    }
}