//---------------------------------------------------
// Purpose: Implementation of Menu class
// Author:	Conrad Haslauer
// Date:	Spring 2024
//---------------------------------------------------
import java.util.Scanner;
import java.util.ArrayList;

public class Menu 
{
	// Private variable - dynamically sized ArrayList
	private ArrayList<Food> menu;

	// Constructor
	public Menu()
	{
		menu = new ArrayList<Food>();
	}

	// Add food item to menu
	public void addFood(Food food)
	{
		menu.add(food);
	}

	// Order food item and get price
	public double orderFood(int itemNum)
	{
		//valid item number chosen
		if ((itemNum > 0) && (itemNum <= menu.size()))
		{
			System.out.printf("\tOrdering: %s for $%3.2f\n", menu.get(itemNum-1).getName(), menu.get(itemNum-1).getPrice());
			return menu.get(itemNum-1).getPrice();
		}
		else
			return 0;
	}

	// Print all items on menu
	public void printMenu()
	{
		System.out.println("\t\t+-----------------------+");
		System.out.println("\t\t|Conrad's Restaurant Menu|");
		System.out.println("\t\t+-----------------------+");
		for (int index = 0; index < menu.size(); index++)
		{
		   System.out.print("Item: " + (index+1) + ") ");
		   menu.get(index).print();
		   System.out.println();
		}
	}
	
	// Main program
	public static void main(String[] args) 
	{
		// Create and print menu
		Menu menu = new Menu();
		menu.addFood( new MainCourse("Signature Taco", "Deliciousness wrapped in a warm tortilla for an explosion of flavor in every bite", 6.99, "Main Course",'n','n') );
		menu.addFood( new MainCourse("Crunchy Fish Taco", "Lime marinated cod with spicy cabbage slaw", 7.99, "Main Course",'n','n') );
		menu.addFood( new MainCourse("Spicy Shrimp Taco", "Grilled shrimp, fiery salsa, and cool avocado in a warm tortilla", 8.99, "Main Course",'n','n') );
		menu.addFood( new MainCourse("Fettuccine Alfredo", "Creamy fettuccine pasta with homemade Alfredo sauce.", 10.99, "Main Course", 'n','n'));
		menu.addFood( new MainCourse("Vegetable Stir-Fry", "A colorful medley of stir-fried vegetablesn a savory soy-ginger sauce.", 25.99, "Main Course", 'y','y'));
		menu.addFood( new MainCourse("Eggplant Parmesan", "Layers of breaded and fried eggplant slices, marinara sauce, and melted mozzarella cheese.", 22.99, "Main Course", 'y','n'));
		menu.addFood( new Appetizer("Mini Crab Cakes", "Bite-sized crab cakes made with lump crab meat, breadcrumbs, and seasonings.", 12.99, "Appetizer", 5 , "Hot"));
		menu.addFood( new Appetizer("Stuffed Mushrooms", "Mushroom caps filled with a savory mixture of cream cheese, garlic, herbs, and breadcrumbs", 10.99, "Appetizer", 2 , "Hot"));
		menu.addFood( new Appetizer("Bacon-Wrapped Dates", "Sweet dates stuffed with creamy goat cheese, wrapped in crispy bacon, and baked until caramelized.", 7.99, "Appetizer", 3 , "Hot"));
		menu.addFood( new Dessert("New York Cheesecake", "A classic New York-style cheesecake with a graham cracker crust and a creamy, lightly flavored vanilla center.", 24.99, "Dessert", 400, 'n'));
		menu.addFood( new Dessert("Apple Pie", "A fall-inspired pie with apple and cinnamon flavors. It features a pecan and graham cracker crust, ", 14.99, "Dessert", 380, 'y'));
		menu.addFood( new Dessert("Irish Cream Chocolate Ice Cream", "Features Oreo cookie toppings and a chocolate and Irish cream flavored center", 16.99, "Dessert", 420, 'y'));
		menu.printMenu();

		// Get user input
		//System.out.println("Get user input here");
		Scanner scanner = new Scanner(System.in);
        double customerBill = 0.0;
        int itemNumber = 0;
		while (itemNumber >= 0) 
		{
            System.out.print("Enter item number to order (or -1 to finish): ");
            itemNumber = scanner.nextInt();
            double itemPrice = menu.orderFood(itemNumber);
            if (itemPrice > 0) {
                customerBill += itemPrice;
            }
        }
        
        double salesTax = customerBill * 0.08;
        
        double suggestedTip = customerBill * 0.20;
        
        double totalPrice = customerBill + salesTax + suggestedTip;
        
		// Print bill for meal
		//System.out.println("Print bill for meal here");
		System.out.println("Bill:");
        System.out.printf("Food Cost: %.2f\n", customerBill);
        System.out.printf("Sales Tax: %.2f\n", salesTax);
        System.out.printf("Suggested Tip: %.2f\n", suggestedTip);
        System.out.printf("Total Cost: %.2f\n", totalPrice);
		
	}
}